import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'login.dart';

class SignUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;

    return Container(
      width: double.infinity,
      child: Container(
        width: double.infinity,
        height: 800 * fem,
        decoration: BoxDecoration(
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 0 * fem,
              top: 0 * fem,
              child: Align(
                child: SizedBox(
                  width: 362 * fem,
                  height: 802.86 * fem,
                  child: Image.asset(
                    'assets/page-1/images/image-2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 54 * fem,
              top: 107 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 254 * fem,
                    height: 132 * fem,
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: SafeGoogleFont(
                          'Inter',
                          fontSize: 40 * ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.2656960487 * ffem / fem,
                          color: Color(0xffffffff),
                        ),
                        children: [
                          TextSpan(
                            text: 'CONCERT\n',
                            style: SafeGoogleFont(
                              'Lato',
                              fontSize: 50 * ffem,
                              fontWeight: FontWeight.w800,
                              height: 1.3151354486 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                          TextSpan(
                            text: 'CRUSADE',
                            style: SafeGoogleFont(
                              'Lato',
                              fontSize: 40 * ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3151354486 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 111 * fem,
              top: 24 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 137 * fem,
                    height: 34 * fem,
                    child: Text(
                      'YAMSON, KEANA D.\nBSIT 3A',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 15 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1099999367 * ffem / fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 102.5 * fem,
              top: 93 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 154 * fem,
                    height: 27 * fem,
                    child: Text(
                      'ROXAS CITY, CAPIZ',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 18 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.445 * ffem / fem,
                        color: Color(0xfffffdfd),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 67 * fem,
              top: 617 * fem,
              child: Align(
                child: SizedBox(
                  width: 225 * fem,
                  height: 57 * fem,
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100 * fem),
                        border: Border.all(color: Color(0x7fffffff)),
                        color: Color(0xfffb8b70),
                      ),
                      child: Center(
                        child: Text(
                          'SIGN UP',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Jost',
                            fontSize: 20 * ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5112291336 * ffem / fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 303 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 277 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 383 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 357 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 460 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 434 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 540 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 43 * fem,
              top: 514 * fem,
              child: Align(
                child: SizedBox(
                  width: 276 * fem,
                  height: 35 * fem,
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10 * fem),
                    ),
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 133 * fem,
              top: 232 * fem,
              child: Align(
                child: SizedBox(
                  width: 76 * fem,
                  height: 20 * fem,
                  child: Text(
                    'SIGN - UP',
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 16 * ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xfffb8b70),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 78 * fem,
              top: 702 * fem,
              child: Align(
                child: SizedBox(
                  width: 137 * fem,
                  height: 15 * fem,
                  child: Text(
                    'Already have an account?',
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 12 * ffem,
                      fontWeight: FontWeight.w300,
                      height: 1.2125 * ffem / fem,
                      fontStyle: FontStyle.italic,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 224 * fem,
              top: 702 * fem,
              child: Align(
                child: SizedBox(
                  width: 40 * fem,
                  height: 15 * fem,
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Sign In',
                      style: SafeGoogleFont(
                        'Inter',
                        fontSize: 12 * ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125 * ffem / fem,
                        color: Color(0xfffb8b70),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 284 * fem,
              top: 548 * fem,
              child: Align(
                child: SizedBox(
                  width: 26 * fem,
                  height: 20 * fem,
                  child: Image.asset(
                    'assets/page-1/images/icon-eye-slash-eU1.png',
                    width: 26 * fem,
                    height: 20 * fem,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 284 * fem,
              top: 469 * fem,
              child: Align(
                child: SizedBox(
                  width: 26 * fem,
                  height: 20 * fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/icon-eye-slash-cem.png',
                      width: 26 * fem,
                      height: 20 * fem,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
