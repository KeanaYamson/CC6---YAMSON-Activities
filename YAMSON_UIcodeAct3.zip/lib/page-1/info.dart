import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'intro.dart'; // Import the IntroScreen
import 'home.dart'; // Import the HomeScreen

class InfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // info4e5 (20:32)
        padding: EdgeInsets.fromLTRB(
            0 * fem, 14 * fem, 0 * fem, 48 * fem), // Adjusted bottom padding
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xff000000),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-2-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup84tdhiy (CpXERZqsU1A1MBNqEW84td)
              margin: EdgeInsets.fromLTRB(111 * fem, 0 * fem, 16 * fem,
                  54.5 * fem), // Adjusted bottom margin
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Center(
                    // yamsonkeanadbsit3a1Um (20:34)
                    child: Container(
                      margin: EdgeInsets.fromLTRB(
                          0 * fem, 0 * fem, 60 * fem, 0 * fem),
                      constraints: BoxConstraints(
                        maxWidth: 137 * fem,
                      ),
                      child: Text(
                        'YAMSON, KEANA D.\nBSIT 3A',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont(
                          'Jost',
                          fontSize: 15 * ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1099999367 * ffem / fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // logoutEcR (20:191)
                    margin:
                        EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 9 * fem),
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => IntroScreen(),
                          ),
                        );
                      },
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 36 * fem,
                        height: 35 * fem,
                        child: Image.asset(
                          'assets/page-1/images/logout.png',
                          width: 36 * fem,
                          height: 35 * fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Center(
              // concertcrusadeuTf (20:115)
              child: Container(
                margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem,
                    24.5 * fem), // Adjusted bottom margin
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: SafeGoogleFont(
                      'Jost',
                      fontSize: 35 * ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.8299998692 * ffem / fem,
                      letterSpacing: 0.7 * fem,
                      color: Color(0xffffffff),
                    ),
                    children: [
                      TextSpan(
                        text: 'CONCERT',
                        style: SafeGoogleFont(
                          'Jost',
                          fontSize: 50 * ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.8299999237 * ffem / fem,
                          letterSpacing: 1.2 * fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                      TextSpan(
                        text: '   ',
                        style: SafeGoogleFont(
                          'Jost',
                          fontSize: 50 * ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.83 * ffem / fem,
                          letterSpacing: 1 * fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                      TextSpan(
                        text: '                          ',
                      ),
                      TextSpan(
                        text: 'CRUSADE',
                        style: SafeGoogleFont(
                          'Jost',
                          fontSize: 40 * ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.8299999237 * ffem / fem,
                          letterSpacing: 0.7 * fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Center(
              // featuringvQh (20:128)
              child: Text(
                'FEATURING',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Jost',
                  fontSize: 15 * ffem,
                  fontWeight: FontWeight.w300,
                  height: 1.1099998474 * ffem / fem,
                  fontStyle: FontStyle.italic,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupkwhxERP (CpXEdEB7CFHaQyiWUgKwhX)
              margin: EdgeInsets.fromLTRB(7 * fem, 0 * fem, 10 * fem, 11 * fem),
              width: double.infinity,
              height: 285 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // image4A49 (20:117)
                    left: 18.9527893066 * fem,
                    top: 13.7401733398 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 141.76 * fem,
                        height: 93.1 * fem,
                        child: Image.asset(
                          'assets/page-1/images/image-4.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line2SnM (20:118)
                    left: 174 * fem,
                    top: 3 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 1 * fem,
                        height: 282 * fem,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line3MPX (20:127)
                    left: 0 * fem,
                    top: 127 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 343 * fem,
                        height: 1 * fem,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image6scm (20:124)
                    left: 202 * fem,
                    top: 149 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 120 * fem,
                        height: 120 * fem,
                        child: Image.asset(
                          'assets/page-1/images/image-6.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image7CQ9 (20:126)
                    left: 193 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 116 * fem,
                        height: 116 * fem,
                        child: Image.asset(
                          'assets/page-1/images/image-7.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image5W9w (20:120)
                    left: 28 * fem,
                    top: 147 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 130 * fem,
                        height: 130 * fem,
                        child: Image.asset(
                          'assets/page-1/images/image-5.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Center(
              // roxascitycapizCYZ (20:129)
              child: Container(
                margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem,
                    24 * fem), // Adjusted bottom margin
                child: Text(
                  '@ ROXAS CITY, CAPIZ',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont(
                    'Jost',
                    fontSize: 18 * ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.445 * ffem / fem,
                    color: Color(0xfffffdfd),
                  ),
                ),
              ),
            ),
            Container(
              // backhVK (125:43)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 4 * fem, 0 * fem),
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HomeScreen(),
                    ),
                  );
                },
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 26 * fem,
                  height: 32 * fem,
                  child: Image.asset(
                    'assets/page-1/images/back.png',
                    width: 26 * fem,
                    height: 32 * fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
