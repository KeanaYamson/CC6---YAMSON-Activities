import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'intro.dart'; // Import the IntroScreen widget
import 'info.dart'; // Import the InfoScreen widget

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        width: double.infinity,
        height: 800 * fem,
        decoration: BoxDecoration(
          color: Color(0xff000000),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-3-bg.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 32.5 * fem,
              top: 163.5 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 296 * fem,
                    height: 158 * fem,
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: SafeGoogleFont(
                          'Inter',
                          fontSize: 40 * ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.2656960487 * ffem / fem,
                          color: Color(0xffffffff),
                        ),
                        children: [
                          TextSpan(
                            text: 'CONCERT\n',
                            style: SafeGoogleFont(
                              'Lato',
                              fontSize: 50 * ffem,
                              fontWeight: FontWeight.w800,
                              height: 1.3151354486 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                          TextSpan(
                            text: 'CRUSADE',
                            style: SafeGoogleFont(
                              'Lato',
                              fontSize: 50 * ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3151354486 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 111 * fem,
              top: 25 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 137 * fem,
                    height: 34 * fem,
                    child: Text(
                      'YAMSON, KEANA D.\nBSIT 3A',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 15 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1099999367 * ffem / fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 25 * fem,
              top: 351 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 312 * fem,
                    height: 261 * fem,
                    child: Text(
                      'Concert Crusade is a non-profit, a Christian organization committed to the Great Commission and “winning people to faith in Jesus Christ, building them in their faith and sending them to win and build others”. The primary goal is to help the body of Christ to do evangelism and discipleship through various creative approaches.',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 18 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.604999971 * ffem / fem,
                        color: Color(0xfffffdfd),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 102.5 * fem,
              top: 132 * fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 154 * fem,
                    height: 27 * fem,
                    child: Text(
                      'ROXAS CITY, CAPIZ',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 18 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.445 * ffem / fem,
                        color: Color(0xfffffdfd),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 307 * fem,
              top: 21 * fem,
              child: Align(
                child: SizedBox(
                  width: 36 * fem,
                  height: 35 * fem,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => IntroScreen()),
                      );
                    },
                    child: Image.asset(
                      'assets/page-1/images/logout-JxH.png',
                      width: 36 * fem,
                      height: 35 * fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 168 * fem,
              top: 675 * fem,
              child: Align(
                child: SizedBox(
                  width: 26 * fem,
                  height: 32 * fem,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => InfoScreen()),
                      );
                    },
                    child: Image.asset(
                      'assets/page-1/images/next.png',
                      width: 26 * fem,
                      height: 32 * fem,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
