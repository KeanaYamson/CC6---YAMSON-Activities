import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'login.dart';
import 'home.dart'; // Import the home.dart file
import 'signup.dart'; // Import the signup.dart file

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _showPassword = false;

  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;

    return Scaffold(
      body: Container(
        width: double.infinity,
        child: Container(
          padding: EdgeInsets.fromLTRB(43 * fem, 24 * fem, 41 * fem, 115 * fem),
          width: double.infinity,
          decoration: BoxDecoration(
            color: Color(0xff000000),
            image: DecorationImage(
              fit: BoxFit.cover,
              image: AssetImage(
                'assets/page-1/images/image-2-bg-RPw.png',
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Container(
                  margin:
                      EdgeInsets.fromLTRB(0 * fem, 0 * fem, 3 * fem, 85 * fem),
                  constraints: BoxConstraints(
                    maxWidth: 137 * fem,
                  ),
                  child: Text(
                    'YAMSON, KEANA D.\nBSIT 3A',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont(
                      'Jost',
                      fontSize: 15 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1099999367 * ffem / fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
              Container(
                margin:
                    EdgeInsets.fromLTRB(11 * fem, 0 * fem, 11 * fem, 0 * fem),
                width: double.infinity,
                height: 157 * fem,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0 * fem,
                      top: 25 * fem,
                      child: Center(
                        child: Align(
                          child: SizedBox(
                            width: 254 * fem,
                            height: 132 * fem,
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: SafeGoogleFont(
                                  'Inter',
                                  fontSize: 40 * ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.2656960487 * ffem / fem,
                                  color: Color(0xffffffff),
                                ),
                                children: [
                                  TextSpan(
                                    text: 'CONCERT\n',
                                    style: SafeGoogleFont(
                                      'Lato',
                                      fontSize: 50 * ffem,
                                      fontWeight: FontWeight.w800,
                                      height: 1.3151354486 * ffem / fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'CRUSADE',
                                    style: SafeGoogleFont(
                                      'Lato',
                                      fontSize: 40 * ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3151354486 * ffem / fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 48.5 * fem,
                      top: 0 * fem,
                      child: Center(
                        child: Align(
                          child: SizedBox(
                            width: 154 * fem,
                            height: 27 * fem,
                            child: Text(
                              'ROXAS CITY, CAPIZ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont(
                                'Jost',
                                fontSize: 18 * ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.445 * ffem / fem,
                                color: Color(0xfffffdfd),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem,
                    16 * fem), // Reduce the bottom margin
                child: Text(
                  'SIGN - IN ',
                  style: SafeGoogleFont(
                    'Inter',
                    fontSize: 16 * ffem,
                    fontWeight: FontWeight.w800,
                    height: 1.2125 * ffem / fem,
                    color: Color(0xfffb8b70),
                  ),
                ),
              ),
              Container(
                margin:
                    EdgeInsets.fromLTRB(0 * fem, 0 * fem, 187 * fem, 6 * fem),
                child: Text(
                  'USERNAME',
                  style: SafeGoogleFont(
                    'Inter',
                    fontSize: 16 * ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.2125 * ffem / fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem,
                    31 * fem), // Reduce the bottom margin
                width: double.infinity,
                height: 46 * fem,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10 * fem),
                  color: Color(0xe5ffffff),
                ),
                child: TextField(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 10 * fem),
                  ),
                ),
              ),
              Container(
                margin:
                    EdgeInsets.fromLTRB(0 * fem, 0 * fem, 187 * fem, 6 * fem),
                child: Text(
                  'PASSWORD',
                  style: SafeGoogleFont(
                    'Inter',
                    fontSize: 16 * ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.2125 * ffem / fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem,
                    29 * fem), // Reduce the bottom margin
                padding:
                    EdgeInsets.fromLTRB(241 * fem, 13 * fem, 9 * fem, 13 * fem),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color(0xe5ffffff),
                  borderRadius: BorderRadius.circular(10 * fem),
                ),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        _showPassword = !_showPassword;
                      });
                    },
                    child: SizedBox(
                      width: 26 * fem,
                      height: 20 * fem,
                      child: Image.asset(
                        _showPassword
                            ? 'assets/page-1/images/icon-eye.png'
                            : 'assets/page-1/images/icon-eye-slash.png',
                        width: 26 * fem,
                        height: 20 * fem,
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(24 * fem, 0 * fem, 27 * fem,
                    12 * fem), // Reduce the bottom margin
                width: double.infinity,
                height: 57 * fem,
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0x7fffffff)),
                  color: Color(0xfffb8b70),
                  borderRadius: BorderRadius.circular(100 * fem),
                ),
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              HomeScreen()), // Navigate to home.dart
                    );
                  },
                  child: Center(
                    child: Text(
                      'SIGN IN',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 20 * ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.5112291336 * ffem / fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                margin:
                    EdgeInsets.fromLTRB(42 * fem, 0 * fem, 49 * fem, 0 * fem),
                width: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(
                          0 * fem, 0 * fem, 8 * fem, 0 * fem),
                      child: Text(
                        'Don’t have an account?',
                        style: SafeGoogleFont(
                          'Inter',
                          fontSize: 12 * ffem,
                          fontWeight: FontWeight.w300,
                          height: 1.2125 * ffem / fem,
                          fontStyle: FontStyle.italic,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  SignUpScreen()), // Navigate to signup.dart
                        );
                      },
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: Text(
                        'Sign Up',
                        style: SafeGoogleFont(
                          'Inter',
                          fontSize: 12 * ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2125 * ffem / fem,
                          color: Color(0xfffb8b70),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
