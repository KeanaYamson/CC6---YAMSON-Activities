import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'login.dart';

class IntroScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;

    void navigateToLogin() {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    }

    return Container(
      width: double.infinity,
      child: Container(
        // introoJR (1:2)
        padding: EdgeInsets.fromLTRB(2 * fem, 24 * fem, 2 * fem, 93 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xff000000),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-1-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              // yamsonkeanadbsit3atam (9:7)
              child: Container(
                margin:
                    EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 86 * fem),
                constraints: BoxConstraints(
                  maxWidth: 137 * fem,
                ),
                child: Text(
                  'YAMSON, KEANA D.\nBSIT 3A',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont(
                    'Jost',
                    fontSize: 15 * ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.1099999367 * ffem / fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupek6zmPf (CpXGa66ii2uZNPa6NxEk6Z)
              margin:
                  EdgeInsets.fromLTRB(0 * fem, 0 * fem, 68 * fem, 14.5 * fem),
              width: 254 * fem,
              height: 156 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // concertcrusadeV4m (3:6)
                    left: 0 * fem,
                    top: 24 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 254 * fem,
                        height: 132 * fem,
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont(
                              'Inter',
                              fontSize: 40 * ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2656960487 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                            children: [
                              TextSpan(
                                text: 'CONCERT\n',
                                style: SafeGoogleFont(
                                  'Lato',
                                  fontSize: 50 * ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.3151354486 * ffem / fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                              TextSpan(
                                text: 'CRUSADE',
                                style: SafeGoogleFont(
                                  'Lato',
                                  fontSize: 40 * ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3151354486 * ffem / fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // roxascitycapiz7EZ (10:19)
                    left: 83.5 * fem,
                    top: 0 * fem,
                    child: Center(
                      child: Align(
                        child: SizedBox(
                          width: 154 * fem,
                          height: 27 * fem,
                          child: Text(
                            'ROXAS CITY, CAPIZ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont(
                              'Jost',
                              fontSize: 18 * ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.445 * ffem / fem,
                              color: Color(0xfffffdfd),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // wewillstartanewinthepresenceof (4:2)
              margin:
                  EdgeInsets.fromLTRB(0 * fem, 0 * fem, 13 * fem, 62.5 * fem),
              constraints: BoxConstraints(
                maxWidth: 309 * fem,
              ),
              child: Text(
                'We will start anew in the presence of the Lord through praise. Let us sing, dance and shout for joy in this concert!',
                style: SafeGoogleFont(
                  'Jost',
                  fontSize: 18 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.445 * ffem / fem,
                  color: Color(0xfffffdfd),
                ),
              ),
            ),
            Container(
              // autogroupu5edxuP (CpXGg16Xrcb2Vhgkvau5ed)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 65 * fem, 0 * fem),
              height: 251 * fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // wannajoinnowgaV (9:13)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 63 * fem, 5 * fem, 0 * fem),
                    constraints: BoxConstraints(
                      maxWidth: 174 * fem,
                    ),
                    child: Text(
                      'WANNA JOIN NOW?!',
                      textAlign: TextAlign.right,
                      style: SafeGoogleFont(
                        'Jost',
                        fontSize: 32 * ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.445 * ffem / fem,
                        color: Color(0xfffffdfd),
                      ),
                    ),
                  ),
                  Container(
                    // line1mM3 (9:14)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 18 * fem, 0 * fem),
                    width: 1 * fem,
                    height: 251 * fem,
                    decoration: BoxDecoration(
                      color: Color(0xffffffff),
                    ),
                  ),
                  GestureDetector(
                    onTap: navigateToLogin, // Navigate to LoginScreen
                    child: Container(
                      // autogroupgcz9VXw (CpXGnv4gQhegjy9LYkGCz9)
                      margin: EdgeInsets.fromLTRB(
                          0 * fem, 95 * fem, 0 * fem, 94 * fem),
                      width: 93 * fem,
                      height: double.infinity,
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0x7fffffff)),
                        color: Color(0xfffb8b70),
                        borderRadius: BorderRadius.circular(100 * fem),
                      ),
                      child: Center(
                        child: Text(
                          'START',
                          style: SafeGoogleFont(
                            'Jost',
                            fontSize: 18 * ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5112291972 * ffem / fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
