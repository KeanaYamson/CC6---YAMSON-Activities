package com.example.prjyamsonfinalexam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
